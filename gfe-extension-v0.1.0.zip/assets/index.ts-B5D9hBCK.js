class u{inject(){const e=document.createElement("script");e.src=chrome.runtime.getURL("injected.js"),e.type="module",console.warn("[GFE Sync] injecting script:",e.src),(document.head??document.documentElement).appendChild(e),e.addEventListener("load",()=>{console.warn("[GFE Sync] injected.js loaded"),e.remove()}),e.addEventListener("error",s=>console.warn("[GFE Sync] injected.js load error:",s))}listen(){window.addEventListener("message",e=>{if(e.origin!==location.origin)return;const t=e.data;!t||t.type!=="GFE_COMPLETE"||(console.warn("[GFE Sync] content bridge: forwarding to background"),chrome.runtime.sendMessage({type:"QUESTION_COMPLETED",payload:{workspace:t.workspace,metadata:t.metadata,timestamp:t.timestamp,pageUrl:t.pageUrl}}))})}}const p="gfe-ext-toast-host";class f{host=null;dismissTimer=null;show(e,t){this.clear();const s=document.createElement("div");s.id=p,Object.assign(s.style,{position:"fixed",top:"20px",right:"20px",zIndex:"2147483647",pointerEvents:"none"});const d=s.attachShadow({mode:"open"}),l=document.createElement("style");l.textContent=`
      * { box-sizing: border-box; margin: 0; padding: 0; }
      .toast {
        display: flex;
        align-items: flex-start;
        gap: 10px;
        padding: 12px 14px;
        border-radius: 12px;
        font-family: Inter, ui-sans-serif, system-ui, -apple-system, sans-serif;
        font-size: 14px;
        line-height: 1.45;
        pointer-events: auto;
        border: 1px solid;
        box-shadow: 0 4px 20px rgba(0,0,0,0.14), 0 1px 6px rgba(0,0,0,0.08);
        max-width: 320px;
        min-width: 200px;
        animation: slide-in 0.22s cubic-bezier(0.22, 1, 0.36, 1);
      }
      .toast--success { background:#ecfdf5; border-color:#a7f3d0; color:#065f46; }
      .toast--error   { background:#fef2f2; border-color:#fca5a5; color:#991b1b; }
      .icon { font-size:15px; font-weight:700; flex-shrink:0; line-height:1.45; }
      .msg  { flex:1; word-break:break-word; }
      .label {
        display: block;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        opacity: 0.6;
        margin-bottom: 3px;
      }
      .text { font-weight: 500; }
      @keyframes slide-in {
        from { opacity:0; transform:translateX(20px) scale(0.97); }
        to   { opacity:1; transform:translateX(0)    scale(1);    }
      }
      @media (prefers-color-scheme: dark) {
        .toast--success { background:#0d2818; border-color:#1a4d1a; color:#3fb950; }
        .toast--error   { background:#2d0000; border-color:#450a0a; color:#ff7b72; }
      }
    `;const n=document.createElement("div");n.className=`toast toast--${e}`;const a=document.createElement("span");a.className="icon",a.setAttribute("aria-hidden","true"),a.textContent=e==="success"?"✓":"✕";const r=document.createElement("span");r.className="msg";const i=document.createElement("span");i.className="label",i.textContent=e==="success"?"GFE Sync":"GFE Sync — Error";const c=document.createElement("span");c.className="text",c.textContent=t,r.appendChild(i),r.appendChild(c),n.appendChild(a),n.appendChild(r),d.appendChild(l),d.appendChild(n),document.body?.appendChild(s),this.host=s;const m=()=>{this.dismissTimer=setTimeout(()=>this.clear(),3e3)};n.addEventListener("mouseenter",()=>{this.dismissTimer&&clearTimeout(this.dismissTimer)}),n.addEventListener("mouseleave",()=>m()),m()}clear(){this.dismissTimer&&(clearTimeout(this.dismissTimer),this.dismissTimer=null),this.host?.remove(),this.host=null,document.querySelector(`#${p}`)?.remove()}}const h=new u;h.inject();h.listen();const g=new f;chrome.runtime.onMessage.addListener(o=>{if(typeof o=="object"&&o!==null&&o.type==="SHOW_PAGE_TOAST"){const{payload:e}=o;g.show(e.type,e.message)}});
